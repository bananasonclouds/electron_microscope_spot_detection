# UZH Corporate Design LaTeX Beamer Theme

This is a LaTeX template for presentations implemented according to the [UZH Corporate Design (CD) guidelines](https://www.cd.uzh.ch/).

## Usage

See `template.tex` for a basic usage example. The template is based on the `beamer` class, so you can use all the usual [`beamer`](https://tug.ctan.org/macros/latex/contrib/beamer/doc/beameruserguide.pdf) commands and environments `\frametitle{...}` `\begin{columns}...\end{columns}`, etc.).

### Helper commands

- **`\fillimage[<options>]{<width>}{<height>}{<image-path>}`**: Insert an image that fills the specified width and height. The image is centered and cropped if necessary. Options are passed on to `\includegraphics`.  
  Example: `\fillimage{\textwidth}{5cm}{my-image.jpg}`
- **`\imagecard[<height>]{<image-path>}{<title>}{<subtitle>}`**: Insert an image card with an image filling the available width and the specified height. The title and subtitle are displayed below the image.  
  Example: `\imagecard[5cm]{my-image.jpg}{Title}{Subtitle}`
- **`\numberoverlay{<content>}`**: Display a huge number (or any other content) on a blue background (according to the CD PowerPoint template). Any other content on the same slide will be hidden.  
  Example: `\numberoverlay{42}`

### Colors

The theme makes the CD color palette available for use in your presentation.

| Color name | Accent                 | Shade 1                    | Shade 2                    | Shade 3                    | Shade 4                    | Shade 5                    |
| ---------- | ---------------------- | -------------------------- | -------------------------- | -------------------------- | -------------------------- | -------------------------- |
| Blue       | `uzh@blue` `#0028a5`   | `uzh@blue1` `#bdc9e8`      | `uzh@blue2` `#7596ff`      | `uzh@blue3` `#3062ff`      | `uzh@blue4` `#001e7c`      | `uzh@blue5` `#001452`      |
| Cyan       | `uzh@cyan` `#4ac9e3`   | `uzh@cyan1` `#dbf4f9`      | `uzh@cyan2` `#b7e9f4`      | `uzh@cyan3` `#92dfee`      | `uzh@cyan4` `#1ea7c4`      | `uzh@cyan5` `#147082`      |
| Apple      | `uzh@apple` `#a4d233`  | `uzh@apple1` `#ecf6d6`     | `uzh@apple2` `#dbedad`     | `uzh@apple3` `#c8e485`     | `uzh@apple4` `#7ca023`     | `uzh@apple5` `#536b18`     |
| Gold       | `uzh@gold` `#ffc845`   | `uzh@gold1` `#fff4da`      | `uzh@gold2` `#ffe9b5`      | `uzh@gold3` `#ffde8f`      | `uzh@gold4` `#f3ab00`      | `uzh@gold5` `#a27200`      |
| Orange     | `uzh@orange` `#fc4c02` | `uzh@orange1` `#ffdbcc`    | `uzh@orange2` `#feb799`    | `uzh@orange3` `#fe9367`    | `uzh@orange4` `#bd3902`    | `uzh@orange5` `#7e2601`    |
| Berry      | `uzh@berry` `#bf0d3e`  | `uzh@berry1` `#fbc6d4`     | `uzh@berry2` `#f78caa`     | `uzh@berry3` `#f3537f`     | `uzh@berry4` `#8f0a2e`     | `uzh@berry5` `#60061f`     |
| Grey       |                        | `uzh@grey1` `#666666`      | `uzh@grey2` `#c2c2c2`      | `uzh@grey3` `#a3a3a3`      | `uzh@grey4` `#4d4d4d`      | `uzh@grey5` `#333333`      |
| Light Grey |                        | `uzh@lightgrey1` `#fafafa` | `uzh@lightgrey2` `#efefef` | `uzh@lightgrey3` `#e7e7e7` | `uzh@lightgrey4` `#e0e0e0` | `uzh@lightgrey5` `#d7d7d7` |

Examples:

- `\textcolor{uzh@blue}{Blue text}`
- `\color{uzh@blue} Blue text`

## Accessibility

The PDFs produced by LaTeX are not accessible to users of [screen readers](https://en.wikipedia.org/wiki/Screen_reader). You can use the `latex2html.sh` script to convert your presentation into a more accessible HTML file that can be opened in the browser:

```bash
./latex2html.sh my-presentation.tex
```

The script requires [Pandoc](https://pandoc.org/) to be installed. The generated HTML file `my-presentation.html` will embed all necessary resources, including images, meaning it may be rather large.

### Alternative texts for images

Use `\includegraphics` and `\fillimage` with the `alt` option to provide alternative texts for images. For decorative images, use an empty alternative text:

- `\includegraphics[width=5cm,alt={Alternative text}]{my-image.jpg}`
- `\fillimage[alt={}]{5cm}{3cm}{my-decorative-image.jpg}`
